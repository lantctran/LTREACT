import wrapperFactory from './src/wrapper';

export default (options = {}) => ({
  wrapperFactory,
  options
});
