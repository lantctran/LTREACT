import BootstrapTable from './src/bootstrap-table';
import withDataStore from './src/container';

export default withDataStore(BootstrapTable);

