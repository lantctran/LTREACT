export const FILTER_TYPE = {
  TEXT: 'TEXT',
  SELECT: 'SELECT'
};

export const FILTER_DELAY = 500;
