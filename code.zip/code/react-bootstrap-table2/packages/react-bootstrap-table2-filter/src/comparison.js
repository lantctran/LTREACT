export const LIKE = 'LIKE';
export const EQ = '=';
