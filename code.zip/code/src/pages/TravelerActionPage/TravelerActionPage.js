import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { actGetTravelerRequest } from './../../actions/DS1552/index';
import { connect } from 'react-redux';
import { actGetProductRequest } from '../../actions/index';

class TravelerActionPage extends Component {

    constructor(props) {
        super(props);
        this.state = {
            id: '',
            lblFirstName: '',
            lblLastName: '',
            lblFromOrg: '',
            lblToOrg: ''
        };
    }

    componentDidMount() {
        var { match } = this.props;
        if (match) {
            var id = match.params.id;
            this.props.onViewTraveler(id);
        }
    }

 

    render() {
        var { lblFirstName, lblLastName, lblFromOrg, lblToOrg } = this.state;
        return (
            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <form onSubmit={this.onSave}>
                    <div className="form-group">
                        <label>First Name: </label>
                        <label>{lblFirstName} </label>                 
                    </div>
                    <div className="form-group">
                    <label>Last Name: </label>
                    <label>{lblLastName} </label>
                    </div>
                    <div className="form-group">
                    <label>From Organization: </label>
                    <label>{lblFromOrg} </label>
                    </div>         
                    <div className="form-group">
                    <label>To Organization: </label>
                    <label>{lblToOrg} </label>
                    </div>         
                </form>

            </div>
        );
    }

}

const mapStateToProps = state => {
    return {
        itemEditing : state.itemEditing
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
 
        onViewTraveler : (id) => {
            dispatch(actGetTravelerRequest(id));
        },
     
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(TravelerActionPage);
