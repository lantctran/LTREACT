import React, { Component } from 'react';
import TravelerItem from './../../components/TravelerItem/TravelerItem';
import TravelerList from './../../components/TravelerList/TravelerList';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import { actFetchDS1552SubmittedTravelersRequest } from './../../actions/DS1552/index';
import 'bootstrap/dist/css/bootstrap.min.css';
function enumFormatter(cell, row, enumObject) {
    return enumObject[cell];
  }
  function dateFormatter(cell, row) {
    if (typeof cell !== 'object') {
      cell = new Date(cell);
  
    }
  
    return `${('0' + (cell.getMonth() + 1)).slice(-2)}/${('0' + cell.getDate()).slice(-2)}/${cell.getFullYear()}`;
  }
  class ViewFormatter extends React.Component {
    render() {
      return (
        <Link to={"/Traveler/" + this.props.TM_EVENT_GUID + "/View"} className="btn btn-success mr-10">
        View
    </Link>);
   
    }
  }
  
  function viewFormatter(cell, row) {
    return (
      <ViewFormatter TM_EVENT_GUID={ cell } />
    );
  }
class TravelerListPage extends Component {

    componentDidMount() {
        this.props.fetchAllTravelers();
    }
    
    render() {
     
        var { travelers } = this.props;
        if (travelers.length > 0)
    {
        const options = {
            page: 1,  // which page you want to show as default
            sizePerPageList: [ {
                text: '5', value: 5
              }, {
                text: '10', value: 10
              }, {
                text: 'All', value: travelers.length
              } ], // you can change the dropdown list for size per page
              sizePerPage: 5,  // which size per page you want to locate as default
              pageStartIndex: 1, // where to start counting the pages
              paginationSize: 3,  // the pagination bar size.
              prePage: 'Prev', // Previous page button text
              nextPage: 'Next', // Next page button text
              firstPage: 'First', // First page button text
              lastPage: 'Last', // Last page button text
              prePageTitle: 'Go to previous', // Previous page button title
              nextPageTitle: 'Go to next', // Next page button title
              firstPageTitle: 'Go to first', // First page button title
              lastPageTitle: 'Go to Last', // Last page button title
              paginationShowsTotal: this.renderShowsTotal,  // Accept bool or function
              paginationPosition: 'top'  // default is bottom, top and both is all available
              // keepSizePerPageState: true //default is false, enable will keep sizePerPage dropdown state(open/clode) when external rerender happened
              // hideSizePerPage: true > You can hide the dropdown for sizePerPage
              // alwaysShowAllBtns: true // Always show next and previous button
              // withFirstAndLast: false > Hide the going to First and Last page button
              // hidePageListOnlyOnePage: true > Hide the page list if only one page.
          };
        return (
            <div className="panel panel-primary">
                <div className="panel-heading">
                    <h3 className="panel-title">Travelers</h3>
                </div>
                <div className="panel-body">
    <BootstrapTable data={ travelers } striped={ true } keyField="TM_EVENT_GUID" hover={ true }
    pagination={ true } options = { options } >

        <TableHeaderColumn dataField="FIRST_NAME" dataSort={true}
            filter={ { type: 'TextFilter', delay: 100 }} >First name</TableHeaderColumn>
        <TableHeaderColumn dataField="LAST_NAME"
        filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Last name</TableHeaderColumn>
        <TableHeaderColumn dataField="POSITION_TITLE" 
        filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Position Title</TableHeaderColumn>
        <TableHeaderColumn dataField="ASSIGNMENT_NUMBER" 
        filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Assignment Number</TableHeaderColumn>
        <TableHeaderColumn dataField="ORG_NAME" 
         
        dataSort={true}>Organization</TableHeaderColumn>
        <TableHeaderColumn dataField="ASSIGNMENT_DATE" 
        dataFormat={ dateFormatter }  
        dataSort={true}
        >Assignment Date</TableHeaderColumn>
        <TableHeaderColumn dataField="EFFECTIVE_DATE" 
            dataFormat={ dateFormatter } 
            dataSort={true}
        >Effective Date</TableHeaderColumn>
             <TableHeaderColumn dataField="TM_EVENT_GUID" dataFormat={ viewFormatter }>View</TableHeaderColumn>
    </BootstrapTable>
            </div>
            </div>
        );
    }
        else
        {
        return(

            <div></div>
        )

        ;
    }
}

    showTravelers(travelers) {
        var result = null;
        const options = {
            page: 0,  // which page you want to show as default
            sizePerPageList: [ {
              text: '5', value: 5
            }, {
              text: '10', value: 10
            }, {
              text: 'All', value: travelers.length
            } ], // you can change the dropdown list for size per page
            sizePerPage: 5,  // which size per page you want to locate as default
            pageStartIndex: 0, // where to start counting the pages
            paginationSize: 3,  // the pagination bar size.
            prePage: 'Prev', // Previous page button text
            nextPage: 'Next', // Next page button text
            firstPage: 'First', // First page button text
            lastPage: 'Last', // Last page button text
            prePageTitle: 'Go to previous', // Previous page button title
            nextPageTitle: 'Go to next', // Next page button title
            firstPageTitle: 'Go to first', // First page button title
            lastPageTitle: 'Go to Last', // Last page button title
            paginationShowsTotal: this.renderShowsTotal,  // Accept bool or function
            paginationPosition: 'top'  // default is bottom, top and both is all available
            // keepSizePerPageState: true //default is false, enable will keep sizePerPage dropdown state(open/clode) when external rerender happened
            // hideSizePerPage: true > You can hide the dropdown for sizePerPage
            // alwaysShowAllBtns: true // Always show next and previous button
            // withFirstAndLast: false > Hide the going to First and Last page button
            // hidePageListOnlyOnePage: true > Hide the page list if only one page.
          };
        if (travelers.length > 0) {
            result =  (
            <BootstrapTable data={ travelers } striped={ true } keyField="TM_EVENT_GUID" hover={ true }
            pagination={ true } options={ options }>
                <TableHeaderColumn  dataSort={false}>
                    View
                </TableHeaderColumn>
                <TableHeaderColumn dataField="FIRST_NAME" dataSort={true}
                    filter={ { type: 'TextFilter', delay: 100 }} >First name</TableHeaderColumn>
                <TableHeaderColumn dataField="LAST_NAME"
                filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Last name</TableHeaderColumn>
                <TableHeaderColumn dataField="POSITION_TITLE" 
                filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Position Title</TableHeaderColumn>
                <TableHeaderColumn dataField="ASSIGNMENT_NUMBER" 
                filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Assignment Number</TableHeaderColumn>
                <TableHeaderColumn dataField="ORG_NAME" 
                filter={ { type: 'TextFilter', delay: 100 }} dataSort={true}>Organization</TableHeaderColumn>
                <TableHeaderColumn dataField="ASSIGNMENT_DATE" 
                dataFormat={ dateFormatter } filter={ { type: 'DateFilter' } }
                dataSort={true}
                >Assignment Date</TableHeaderColumn>
                <TableHeaderColumn dataField="EFFECTIVE_DATE" 
                    dataFormat={ dateFormatter } filter={ { type: 'DateFilter' } }
                    dataSort={true}
                >Effective Date</TableHeaderColumn>
                
            </BootstrapTable>
         );
        }
        return result;
    }

}

const mapStateToProps = state => {
    return {
        travelers: state.travelers
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        fetchAllTravelers : () => {
            dispatch(actFetchDS1552SubmittedTravelersRequest());
        },
 
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TravelerListPage);
