//export const API_URL = 'https://pcstravelapi.azurewebsites.net/api/Product';
export const API_URL = 'http://localhost:3000';